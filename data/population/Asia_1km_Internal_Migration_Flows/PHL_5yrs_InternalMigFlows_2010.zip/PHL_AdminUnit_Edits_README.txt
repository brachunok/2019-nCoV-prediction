The following edits have been made before extracting the centroids:

1) polygons in the GADM shapefile representing Lanao del Sur, Shariff Kabunsuan, and Maguindanao have been merged together;

2) polygons in the Admin-1 GADM shapefile representing Dinagat Islands and Surigao del Norte have been merged together;

3) polygons in the Admin-1 GADM shapefile representing Zamboanga Sibugay and Zamboangadel Sur have been merged together;

4) polygons in the Admin-1 GADM shapefile representing South Cotabato and Sarangani have been merged together.