The following edits have been made before extracting the centroids:

1) polygons in the GADM shapefile representing the provinces of Chongqing and Sichuan have been merged together;

2) polygons in the GADM shapefile representing Paracel Islands have been removed.