The following edits have been made before extracting the centroids:

polygons in the Admin-2 GADM shapefile representing the province of Ha Tay and the city of Ha Noi have been merged together.