The following edits have been made before extracting the centroids:

1) polygons in the Admin-1 GADM shapefile representing the states of Uttaranchal and Uttar Pradesh have been merged together;

2) polygons in the Admin-1 GADM shapefile representing the states of Bihar and Jharkhand have been merged together;

3) polygons in the Admin-1 GADM shapefile representing the states of Madhya Pradesh and Chhattisgarh have been merged together.