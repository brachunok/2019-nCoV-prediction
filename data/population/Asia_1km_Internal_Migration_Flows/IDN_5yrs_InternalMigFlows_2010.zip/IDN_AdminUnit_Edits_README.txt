The following edits have been made before extracting the centroids:

1) polygons in the Admin-1 GADM shapefile representing the provinces of Banten and Jawa Barat have been merged together;

2) polygons in the Admin-1 GADM shapefile representing the provinces of Maluku and Maluku Utara have been merged together;

3) polygons in the Admin-1 GADM shapefile representing the provinces of Gorontalo and Sulawesi Utara have been merged together;

4) polygons in the Admin-1 GADM shapefile representing the provinces of Papua and Irian Jaya Barat have been merged together;

5) polygons in the Admin-1 GADM shapefile representing the provinces of Riau and Kepulauan Riau have been merged together;

6) polygons in the Admin-1 GADM shapefile representing the provinces of Sumatera Selatan and Bangka-Belitung have been merged together.
